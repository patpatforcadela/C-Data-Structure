#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>
#include <unistd.h>
#include <windows.h>


char again[5], repeat[5];
int i, length, output, numInput[10], checker;
COORD coord = {0,0};

void gotoxy(int x, int y)
{
    coord.X = x + 17; coord.Y = y + 2;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void drawRectangle()
{
    int i, j;
    gotoxy(0,-1);
    printf("%c",201);
    for(i = 1; i < 85; i++){
        gotoxy(i, -1);
        printf("%c",205);
    }
    gotoxy(85,-1);
    printf("%c",187);
    for(i = 0; i < 25; i++){
        gotoxy(85, i);
        if(i == 5){
            printf("%c",185);
        }else{
            printf("%c",186);
        }
    }
    gotoxy(85, 25);
    printf("%c",188);
    for(i = 84; i > 0; i--){
        gotoxy(i,25);
        if(i == 30){
            printf("%c",202);
        }else{
            printf("%c",205);
        }
    }

    gotoxy(0,25);
    printf("%c",200);
    for(i = 24; i > -1; i--){
        gotoxy(0,i);
        if(i == 5){
            printf("%c",204);
        }else{
            printf("%c",186);
        }
    }

    for(i = 1; i < 85; i++){
        gotoxy(i,5);
        if(i == 30){
            printf("%c",203);
        }else{
            printf("%c",205);
        }
    }

    for(i = 6; i < 25; i++){
        gotoxy(30,i);
        printf("%c",186);
    }

}

void SetColor(int ForgC)
{
     WORD wColor;
     HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
     CONSOLE_SCREEN_BUFFER_INFO csbi;

     if(GetConsoleScreenBufferInfo(hStdOut, &csbi))
     {
          wColor = (csbi.wAttributes & 0xF0) + (ForgC & 0x0F);
          SetConsoleTextAttribute(hStdOut, wColor);
     }
     return;
}

void SetColorAndBackground(int ForgC, int BackC)
{
     WORD wColor = ((BackC & 0x0F) << 4) + (ForgC & 0x0F);;
     SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), wColor);
     return;
}

void clearWindow()
{
    int i,j;
    for(i = 32; i < 85; i++){
        for(j = 6; j < 25; j++){
            gotoxy(i,j);printf(" ");
        }
    }
    return;
}

void loadBar()
{
	gotoxy(35, 10); printf("Loading");
	gotoxy(23, 12);
	sleep(1);
	int r,q;
	for(r=1; r<=11; r++)
	{
		for(q =0; q<=2; q++)
		{
			printf("%c",219);
			usleep(100000);
		}
	}
	sleep(2);
	system("cls");
}
void progDetails()
{
	gotoxy(32,6); printf("This program will ask the user to enter three quizzes");
	gotoxy(32,7); printf("   and will display the average grade and remarks.");
	gotoxy(32,8); printf("This program will ask the user to enter 5 student");
	gotoxy(32,9); printf("   record with 3 quizzes and will display the remarks.");
}

struct student
{
	char name[20], remarks[10];
	int id;
	int quiz[3];
};

int _window()
{
	menu:
	char string1[30], string2[30];
	progDetails();
	drawRectangle();
	SetColorAndBackground(31,36);
  	gotoxy(31,1); printf(" Lab Exercise 5 ");
  	gotoxy(23,2); printf(" Created by: Patrick Jan A. Forcadela ");
  	gotoxy(34,3); printf(" BS CoE 2-1 ");
  	SetColorAndBackground(17,15);
  	gotoxy(25,23);
  	char key, input[5], charInput[20], again[5];
	int length, output, numInput[10], num, error = 0;
  	SetColor(28);
	gotoxy(2,6); printf("Program Number 1");
	gotoxy(2,8); printf("Program Number 2");
	gotoxy(2,10); printf("Press 0 to Exit");
	SetColorAndBackground(31,36);
  	gotoxy(2,23); printf("Enter your choice:      ");
  	gotoxy(21,23);
	scanf("%[^\n]%*c", &input);
	SetColorAndBackground(0,15);
	length = strlen(input);
    output = atoi(input);
	for(checker = 0; checker <= length; checker++)
	{
		if(isspace(input[checker]) || isalpha(input[checker]) || output < 0 || output > 8 ||  ((input[0] == '-') && (input[1] == '0')))
		{
			error = 1;
		}
	}
	if(length != 0 && error == 0)
	{
		if(output == 1)
		{
			do
			{
				error = 0;
				int grade;
				student s1;
				clearWindow();
				SetColorAndBackground(0,40);
				gotoxy(50,6); printf(" Program No. 1 ");
				SetColorAndBackground(16,15);
				gotoxy(32,7); printf("Enter the student record: ");
		ID:		
				error = 0;
				gotoxy(32,8); printf("ID number: ");
				scanf("%[^\n]%*c", &string1);
				length = strlen(string1);
				for(checker = 0; checker <= length; checker++)
				{
					if(isspace(string1[checker]) || isalpha(string1[checker]) || ispunct(string1[checker]))
					{
						error = 1;
					}
				}
				if(error == 0 && length != 0)
				{
					s1.id = atoi(string1);
					gotoxy(32,9); printf("Name: ");
					scanf("%[^\n]%*c", &s1.name);
			quiz:	error = 0;
					gotoxy(32,10); printf("Quiz 1: ");
					scanf("%[^\n]%*c", &string1);
					length = strlen(string1);
					for(checker = 0; checker <= length; checker++)
					{
						if(isspace(string1[checker]) || isalpha(string1[checker]) || ispunct(string1[checker]))
						{
							error = 1;
						}
					}
					s1.quiz[1] = atoi(string1);
					if(error == 0 && length != 0 && s1.quiz[1] >= 0 && s1.quiz[1] <= 100)
					{
				quiz2:	error = 0;
						gotoxy(32,11); printf("Quiz 2: ");
						scanf("%[^\n]%*c", &string1);
						length = strlen(string1);
						for(checker = 0; checker <= length; checker++)
						{
							if(isspace(string1[checker]) || isalpha(string1[checker]) || ispunct(string1[checker]))
							{
								error = 1;
							}
						}
						s1.quiz[2] = atoi(string1);
						if(error == 0 && length != 0 && s1.quiz[2] >= 0 && s1.quiz[2] <= 100)
						{
					quiz3:	error = 0;
							gotoxy(32,12); printf("Quiz 3: ");
							scanf("%[^\n]%*c", &string1);
							length = strlen(string1);
							for(checker = 0; checker <= length; checker++)
							{
								if(isspace(string1[checker]) || isalpha(string1[checker]) || ispunct(string1[checker]))
								{
									error = 1;
								}
							}
							s1.quiz[3] = atoi(string1);
							if(error == 0 && length != 0 && s1.quiz[3] >= 0 && s1.quiz[3] <= 100)
							{
								grade = (s1.quiz[1] + s1.quiz[2] + s1.quiz[3]) / 3; 
								if(grade >= 75)
								{
									gotoxy(32,17); printf("Remarks: Passed");
								} else
								{
									gotoxy(32,17); printf("Remarks: Failed");
								}
								gotoxy(32,14); printf("ID: %d ", s1.id);
								gotoxy(32,15); printf("Name: %s ", s1.name);
								gotoxy(32,16); printf("Grades: %d ", grade);
							}else
							{	
								fflush(stdin);
								for(i = 32; i <= 84; i++)
								{
									gotoxy(i,12); printf(" ");
								}
								goto quiz3;
							}
						}else
						{
							fflush(stdin);
							for(i = 32; i <= 84; i++)
							{
								gotoxy(i,11); printf(" ");
							}
							goto quiz2;
						}
					}else
					{
						fflush(stdin);
						for(i = 32; i <= 84; i++)
						{
							gotoxy(i,10); printf(" ");
						}
						goto quiz;
					}
				} else
				{
					fflush(stdin);
					for(i = 32; i <= 84; i++)
					{
						gotoxy(i,8); printf(" ");
					}
					goto ID;
				}
				gotoxy(32,23); printf("Do you want to start again? Note: Yes or No only. ");
				scanf("%s", &again);
				fflush(stdin);
	 		} while((again[0] == 'Y' || again[0] == 'y') || (again[1] == 'E' || again[1] == 'e') || (again[2] == 'S' || again[2] == 's'));
					if((again[0] == 'N' || again[0] == 'n') || (again[1] == 'O' || again[1] == 'o'))
					{
						clearWindow();
						goto menu;
					} else
					{
						gotoxy(32, 24); printf("ERROR: INVALID INPUT! YES OR NO ONLY! ");
					}
		} else if(output == 2)
		{
			do
			{
				int studentNum = 0;
				int grade[5];
				student stud[5];
				while(studentNum < 5)
				{
					error = 0;
					clearWindow();
					SetColorAndBackground(0,40);
					gotoxy(50,6); printf(" Program No. 2 ");
					SetColorAndBackground(16,15);
					gotoxy(32,7); printf("Enter the student record for student no. %d: ", studentNum + 1);
			IDtwo:		
					error = 0;
					gotoxy(32,8); printf("ID number: ");
					scanf("%[^\n]%*c", &string1);
					length = strlen(string1);
					for(checker = 0; checker <= length; checker++)
					{
						if(isspace(string1[checker]) || isalpha(string1[checker]) || ispunct(string1[checker]))
						{
							error = 1;
						}
					}
					if(error == 0 && length != 0)
					{
						stud[studentNum].id = atoi(string1);
						gotoxy(32,9); printf("Name: ");
						scanf("%[^\n]%*c", &stud[studentNum].name);
				quiztwo:	error = 0;
						gotoxy(32,10); printf("Quiz 1: ");
						scanf("%[^\n]%*c", &string1);
						length = strlen(string1);
						for(checker = 0; checker <= length; checker++)
						{
							if(isspace(string1[checker]) || isalpha(string1[checker]) || ispunct(string1[checker]))
							{
								error = 1;
							}
						}
						stud[studentNum].quiz[1] = atoi(string1);
						if(error == 0 && length != 0 && stud[studentNum].quiz[1] >= 0 && stud[studentNum].quiz[1] <= 100)
						{
					quiz2two:	error = 0;
							gotoxy(32,11); printf("Quiz 2: ");
							scanf("%[^\n]%*c", &string1);
							length = strlen(string1);
							for(checker = 0; checker <= length; checker++)
							{
								if(isspace(string1[checker]) || isalpha(string1[checker]) || ispunct(string1[checker]))
								{
									error = 1;
								}
							}
							stud[studentNum].quiz[2] = atoi(string1);
							if(error == 0 && length != 0 && stud[studentNum].quiz[2] >= 0 && stud[studentNum].quiz[2] <= 100)
							{
						quiz3two:	error = 0;
								gotoxy(32,12); printf("Quiz 3: ");
								scanf("%[^\n]%*c", &string1);
								length = strlen(string1);
								for(checker = 0; checker <= length; checker++)
								{
									if(isspace(string1[checker]) || isalpha(string1[checker]) || ispunct(string1[checker]))
									{
										error = 1;
									}
								}
								stud[studentNum].quiz[3] = atoi(string1);
								if(error == 0 && length != 0 && stud[studentNum].quiz[3] >= 0 && stud[studentNum].quiz[3] <= 100)
								{
									grade[studentNum] = (stud[studentNum].quiz[1] + stud[studentNum].quiz[2] + stud[studentNum].quiz[3]) / 3; 
									if(grade[studentNum] >= 75)
									{
										strcpy(stud[studentNum].remarks, "Passed");
									} else
									{
										strcpy(stud[studentNum].remarks, "Failed");
									}	
								}else
								{	
									fflush(stdin);
									for(i = 32; i <= 84; i++)
									{
										gotoxy(i,12); printf(" ");
									}
									goto quiz3two;
								}
							}else
							{
								fflush(stdin);
								for(i = 32; i <= 84; i++)
								{
									gotoxy(i,11); printf(" ");
								}
								goto quiz2two;
							}
						}else
						{
							fflush(stdin);
							for(i = 32; i <= 84; i++)
							{
								gotoxy(i,10); printf(" ");
							}
							goto quiztwo;
						}
					} else
					{
						fflush(stdin);
						for(i = 32; i <= 84; i++)
						{
							gotoxy(i,8); printf(" ");
						}
						goto IDtwo;
					}
					studentNum++;
				}
				gotoxy(32,14); printf("No.");
				gotoxy(37,14); printf("ID");
				gotoxy(48,14); printf("Name");
				gotoxy(70,14); printf("Grade");
				gotoxy(78,14); printf("Remarks");
				for(i = 0; i < 5; i++)
				{
				
					gotoxy(32,15 + i); printf("%d", i+ 1);
					gotoxy(37,15 + i); printf("%d", stud[i].id);
					gotoxy(48,15 + i); printf("%s", stud[i].name);
					gotoxy(70,15 + i); printf("%d", grade[i]);
					gotoxy(78,15 + i); printf("%s", stud[i].remarks);
				}
				gotoxy(32, 23); printf("Do you want to start again? Note: Yes or No only. ");
				scanf("%s", &again);
				fflush(stdin);
			} while((again[0] == 'Y' || again[0] == 'y') || (again[1] == 'E' || again[1] == 'e') || (again[2] == 'S' || again[2] == 's'));
					if((again[0] == 'N' || again[0] == 'n') || (again[1] == 'O' || again[1] == 'o'))
					{
						clearWindow();
						goto menu;
					} else
					{
						gotoxy(32, 24); printf("ERROR: INVALID INPUT! YES OR NO ONLY! ");
					}

		} else if( output == 0)
		{
			return 0;
		}
	}
	else
	{
		gotoxy(32,22); printf("Invalid input!");
		gotoxy(32,23); printf("Do you want to try again? Yes or No only.");
		scanf("%s", &repeat);
		fflush(stdin);
		if((repeat[0] == 'Y' || repeat[0] == 'y') || (repeat[1] == 'E' || repeat[1] == 'e') || (repeat[2] == 'S' || repeat[2] == 's'))
		{
			clearWindow();
			goto menu;
		}
		else if((repeat[0] == 'N' || repeat[0] == 'n') || (repeat[1] == 'O' || repeat[1] == 'o'))
		{
			clearWindow();
			goto menu;
		} else
		{
			gotoxy(32, 24); printf("ERROR: INVALID INPUT! YES OR NO ONLY! ");
		}
	}
}

int main(){
    system("COLOR F0");
    loadBar();
    SetConsoleTitle("Laboratory Exercise 5");
    _window();
    return 0;
}
