#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>
#include <unistd.h>
#include <windows.h>
#include <iostream>

using namespace	std;
char again[5], repeat[5];
int i, length, output, numInput[10], checker;
COORD coord = {0,0};

void gotoxy(int x, int y)
{
    coord.X = x + 17; coord.Y = y + 2;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void drawRectangle()
{
    int i, j;
    gotoxy(0,-1);
    printf("%c",201);
    for(i = 1; i < 85; i++){
        gotoxy(i, -1);
        printf("%c",205);
    }
    gotoxy(85,-1);
    printf("%c",187);
    for(i = 0; i < 25; i++){
        gotoxy(85, i);
        if(i == 5){
            printf("%c",185);
        }else{
            printf("%c",186);
        }
    }
    gotoxy(85, 25);
    printf("%c",188);
    for(i = 84; i > 0; i--){
        gotoxy(i,25);
        if(i == 30){
            printf("%c",202);
        }else{
            printf("%c",205);
        }
    }

    gotoxy(0,25);
    printf("%c",200);
    for(i = 24; i > -1; i--){
        gotoxy(0,i);
        if(i == 5){
            printf("%c",204);
        }else{
            printf("%c",186);
        }
    }

    for(i = 1; i < 85; i++){
        gotoxy(i,5);
        if(i == 30){
            printf("%c",203);
        }else{
            printf("%c",205);
        }
    }

    for(i = 6; i < 25; i++){
        gotoxy(30,i);
        printf("%c",186);
    }

}

void SetColor(int ForgC)
{
     WORD wColor;
     HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
     CONSOLE_SCREEN_BUFFER_INFO csbi;

     if(GetConsoleScreenBufferInfo(hStdOut, &csbi))
     {
          wColor = (csbi.wAttributes & 0xF0) + (ForgC & 0x0F);
          SetConsoleTextAttribute(hStdOut, wColor);
     }
     return;
}

void SetColorAndBackground(int ForgC, int BackC)
{
     WORD wColor = ((BackC & 0x0F) << 4) + (ForgC & 0x0F);;
     SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), wColor);
     return;
}

void clearWindow()
{
    int i,j;
    for(i = 32; i < 85; i++){
        for(j = 6; j < 25; j++){
            gotoxy(i,j);printf(" ");
        }
    }
    return;
}

void loadBar()
{
	gotoxy(35, 10); printf("Loading");
	gotoxy(23, 12);
	sleep(1);
	int r,q;
	for(r=1; r<=11; r++)
	{
		for(q =0; q<=2; q++)
		{
			printf("%c",219);
			usleep(100000);
		}
	}
	sleep(2);
	system("cls");
}
void reverseString(char* str)
{
	int i, l;
	char* beginptr, *endptr, ch;
	l = strlen(str);
	beginptr = str;
	endptr = str;
	for(i = 0; i < l - 1; i ++)
	{
		endptr++;
	}
	for(i = 0; i < l / 2; i++)
	{
		ch = *endptr;
		*endptr = *beginptr;
		*beginptr = ch;
		beginptr++;
		endptr--;
	}
}
int compareString(char str1[], char str2[])
{
	int i = 0, flag;
	while(str1[i] != '\0' && str2[i] != '\0')
	{
		if(str1[i] != str2[i])
		{
			flag = 1;
			break;
		}
		i++;
	}
	if(flag = 0 && str1[i] == '\0' && str2[i] == '\0')
	{
		return 0;
	} else
	{
		i = 0;
		while(str1[i] != '\0' && str2[i] != '\0')
		{
			if(str1[i] > str2[i])
			{
				return 1;
			} else if(str1[i] > str2[i])
			{
				return -1;
			}
			i++;
		}
	}
}

void progDetails()
{
	gotoxy(32,6); printf("This program will display the output from the ");
	gotoxy(32,7); printf("    given program code.");
	gotoxy(32,8); printf("This program will copy the entered string and will");
	gotoxy(32,9); printf("    store to another variable.");
	gotoxy(32,10); printf("This program will compare the two entered string if ");
	gotoxy(32,11); printf("   they are equal or not.");
	gotoxy(32,12); printf("This program will concatenate the first string and ");
	gotoxy(32,13); printf("   and second string.");
	gotoxy(32,14); printf("This program will get the length of the entered ");
	gotoxy(32,15); printf("   string without using strlen function.");
	gotoxy(32,16); printf("This program will reverse the string entered by user");
	gotoxy(32,17); printf("   using pointers.");
}

int _window()
{
	menu:
	char string1[30], string2[30];
	progDetails();
	drawRectangle();
	SetColorAndBackground(31,36);
  	gotoxy(31,1); printf(" Lab Exercise 4 ");
  	gotoxy(23,2); printf(" Created by: Patrick Jan A. Forcadela ");
  	gotoxy(34,3); printf(" BS CoE 2-1 ");
  	SetColorAndBackground(17,15);
  	gotoxy(25,23);
  	char key, input[5], charInput[20], again[5];
	int length, output, numInput[10], num, error = 0;
  	SetColor(28);
	gotoxy(2,6); printf("Program Number 1");
	gotoxy(2,8); printf("Program Number 2");
	gotoxy(2,10); printf("Program Number 3");
	gotoxy(2,12); printf("Program Number 4");
	gotoxy(2,14); printf("Program Number 5");
	gotoxy(2,16); printf("Program Number 6");
	gotoxy(2,18); printf("Press 0 to Exit");
	SetColorAndBackground(31,36);
  	gotoxy(2,23); printf("Enter your choice:      ");
  	gotoxy(21,23);
	scanf("%[^\n]%*c", &input);
	SetColorAndBackground(0,15);
	length = strlen(input);
    output = atoi(input);
	for(checker = 0; checker <= length; checker++)
	{
		if(isspace(input[checker]) || isalpha(input[checker]) || output < 0 || output > 8 ||  ((input[0] == '-') && (input[1] == '0')))
		{
			error = 1;
		}
	}
	if(length != 0 && error == 0)
	{
		if(output == 1)
		{
			do
			{
				clearWindow();
				SetColorAndBackground(0,40);
				gotoxy(50,6); printf(" Program No. 1 ");
				SetColorAndBackground(16,15);
				int x(11), y(6), z(22), *p1, *p2;
				p1 = &z;
				p2 = &x;
				gotoxy(32,8); cout << "x: " << x << " y: " << y << " z: " << z << " *p1: " << *p1 << " *p2: " << *p2 << endl;
				*p1 = *p2;
				z = *p1+2;
				gotoxy(32,9); cout << "x: " << x << " y: " << y << " z: " << z << " *p1: " << *p1 << " *p2: " << *p2 << endl;
				p2 = p1;
				x = z-y;
				gotoxy(32,10); cout << "x: " << x << " y: " << y << " z: " << z << " *p1: " << *p1 << " *p2: " << *p2 << endl;
				*p1 = y;
				gotoxy(32,11); cout << "x: " << x << " y: " << y << " z: " << z << " *p1: " << *p1 << " *p2: " << *p2 << endl;
				p1=&y;
				*p1=y + x;
				gotoxy(32,12); cout << "x: " << x << " y: " << y << " z: " << z << " *p1: " << *p1 << " *p2: " << *p2 << endl;
				x = 1; y=2; z=3;
				p1=p2;
				*p2=*p1+x;
				gotoxy(32,13); cout << "x: " << x << " y: " << y << " z: " << z << " *p1: " << *p1 << " *p2: " << *p2 << endl;
				gotoxy(32,23); printf("Do you want to start again? Note: Yes or No only. ");
				scanf("%s", &again);
				fflush(stdin);
	 		} while((again[0] == 'Y' || again[0] == 'y') || (again[1] == 'E' || again[1] == 'e') || (again[2] == 'S' || again[2] == 's'));
					if((again[0] == 'N' || again[0] == 'n') || (again[1] == 'O' || again[1] == 'o'))
					{
						clearWindow();
						goto menu;
					} else
					{
						gotoxy(32, 24); printf("ERROR: INVALID INPUT! YES OR NO ONLY! ");
					}
		} else if(output == 2)
		{
			do
			{
				clearWindow();
				SetColorAndBackground(0,40);
				gotoxy(50,6); printf(" Program No. 2 ");
				SetColorAndBackground(16,15);
				gotoxy(32,7); printf("Enter your string: ");
				scanf("%[^\n]%*c", &string1);
				for(i = 0; string1[i] != '\0'; ++i)
				{
					string2[i] = string1[i];
				}
				string2[i] = '\0';
				gotoxy(32,9); printf("The string you've entered is %s", string2);
				gotoxy(32, 23); printf("Do you want to start again? Note: Yes or No only. ");
				scanf("%s", &again);
				fflush(stdin);
			} while((again[0] == 'Y' || again[0] == 'y') || (again[1] == 'E' || again[1] == 'e') || (again[2] == 'S' || again[2] == 's'));
					if((again[0] == 'N' || again[0] == 'n') || (again[1] == 'O' || again[1] == 'o'))
					{
						clearWindow();
						goto menu;
					} else
					{
						gotoxy(32, 24); printf("ERROR: INVALID INPUT! YES OR NO ONLY! ");
					}

		} else if(output == 3)
		{
			do
			{
				int result;
				clearWindow();
				SetColorAndBackground(0,40);
				gotoxy(50,6); printf(" Program No. 1 ");
				SetColorAndBackground(16,15);
				gotoxy(32,7); printf("Enter the first string: ");
				scanf("%[^\n]%*c", &string1);
				gotoxy(32,8); printf("Enter the second string: ");
				scanf("%[^\n]%*c", &string2);
				result = compareString(string1, string2);
				if(result == 1)
				{
					gotoxy(32, 19); printf("The second string is greater than the first string");
				} else if(result == -1)
				{
					gotoxy(32, 19); printf("The first string is greater than the second string");
				} else
				{
					gotoxy(32, 19); printf("Both string is equal");
				}
				
				gotoxy(32,23); printf("Do you want to start again? Note: Yes or No only. ");
				scanf("%s", &again);
				fflush(stdin);
	 		} while((again[0] == 'Y' || again[0] == 'y') || (again[1] == 'E' || again[1] == 'e') || (again[2] == 'S' || again[2] == 's'));
					if((again[0] == 'N' || again[0] == 'n') || (again[1] == 'O' || again[1] == 'o'))
					{
						clearWindow();
						goto menu;
					} else
					{
						gotoxy(32, 24); printf("ERROR: INVALID INPUT! YES OR NO ONLY! ");
					}
		} else if(output == 4)
		{
			do
			{
				int j;
				clearWindow();
				SetColorAndBackground(0,40);
				gotoxy(50,6); printf(" Program No. 3 ");
				SetColorAndBackground(16,15);
				gotoxy(32,7); printf("Enter the first string: ");
				scanf("%[^\n]%*c", &string1);
				gotoxy(32,8); printf("Enter the second string: ");
				scanf("%[^\n]%*c", &string2);
				for(i=0; string1[i]!='\0'; ++i); 
				for(j=0; string2[j]!='\0'; ++j, ++i)
				{
				   string1[i] = string2[j];
				}
				string1[i]='\0';
				gotoxy(32,9); printf("The string you've entered is %s", string1);
				gotoxy(32,23); printf("Do you want to start again? Note: Yes or No only. ");
				scanf("%s", &again);
				fflush(stdin);
	 		} while((again[0] == 'Y' || again[0] == 'y') || (again[1] == 'E' || again[1] == 'e') || (again[2] == 'S' || again[2] == 's'));
					if((again[0] == 'N' || again[0] == 'n') || (again[1] == 'O' || again[1] == 'o'))
					{
						clearWindow();
						goto menu;
					} else
					{
						gotoxy(32, 24); printf("ERROR: INVALID INPUT! YES OR NO ONLY! ");
					}
	} else if(output == 5)
	{
			do
			{
				i = 0, length = 0;
				clearWindow();
				SetColorAndBackground(0,40);
				gotoxy(50,6); printf(" Program No. 5 ");
				SetColorAndBackground(16,15);
				gotoxy(32, 8); printf("Enter a string: ");
				scanf("%[^\n]%*c" , &string1);
				while(string1[i] != '\0')
				{
					length++;
					i++;
				}
				gotoxy(32,9); printf("The length of the string you've entered is %d", length);
				gotoxy(32, 23); printf("Do you want to try again? Note: Yes or No only. ");
				scanf("%s", &again);
				fflush(stdin);
			} while((again[0] == 'Y' || again[0] == 'y') || (again[1] == 'E' || again[1] == 'e') || (again[2] == 'S' || again[2] == 's'));
				if((again[0] == 'N' || again[0] == 'n') || (again[1] == 'O' || again[1] == 'o'))
					{
						clearWindow();
						goto menu;
					} else
					{
						gotoxy(32, 24); printf("ERROR: INVALID INPUT! YES OR NO ONLY! ");
					}
	} else if (output == 6)
	{
			do
			{
				clearWindow();
				SetColorAndBackground(0,40);
				gotoxy(50,6); printf(" Program No. 6 ");
				SetColorAndBackground(16,15);
				gotoxy(32, 8); printf("Enter a string: ");
				scanf("%[^\n]%*c" , &string1);
				reverseString(string1);
				gotoxy(32,9); printf("The reverse of the string is %s", string1);
				gotoxy(32, 23); printf("Do you want to try again? Note: Yes or No only. ");
				scanf("%s", &again);
				fflush(stdin);
			} while((again[0] == 'Y' || again[0] == 'y') || (again[1] == 'E' || again[1] == 'e') || (again[2] == 'S' || again[2] == 's'));
				if((again[0] == 'N' || again[0] == 'n') || (again[1] == 'O' || again[1] == 'o'))
					{
						clearWindow();
						goto menu;
					} else
					{
						gotoxy(32, 24); printf("ERROR: INVALID INPUT! YES OR NO ONLY! ");
					}
	}  else if( output == 0)
	{
		return 0;
	}
	}
	else
	{
		gotoxy(32,22); printf("Invalid input!");
		gotoxy(32,23); printf("Do you want to try again? Yes or No only.");
		scanf("%s", &repeat);
		fflush(stdin);
		if((repeat[0] == 'Y' || repeat[0] == 'y') || (repeat[1] == 'E' || repeat[1] == 'e') || (repeat[2] == 'S' || repeat[2] == 's'))
		{
			clearWindow();
			goto menu;
		}
		else if((repeat[0] == 'N' || repeat[0] == 'n') || (repeat[1] == 'O' || repeat[1] == 'o'))
		{
			clearWindow();
			goto menu;
		} else
		{
			gotoxy(32, 24); printf("ERROR: INVALID INPUT! YES OR NO ONLY! ");
		}
	}
}

int main(){
    system("COLOR F0");
    loadBar();
    SetConsoleTitle("Laboratory Exercise 4");
    _window();
    return 0;
}
