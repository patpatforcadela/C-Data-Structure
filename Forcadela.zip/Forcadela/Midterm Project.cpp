#include<stdio.h>
#include<ctype.h>
#include<string.h>
#include<stdlib.h>
#include <unistd.h>
#include <windows.h>
#define SIZE 50

char stack[SIZE];
int top = -1, i, j;
COORD coord = {0,0};
void gotoxy(int x, int y)
{
    coord.X = x + 17; coord.Y = y + 2;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
void drawRectangle()
{
    int i, j;
    for(i = 0; i < 86; i++){ 		//top horizontal
        gotoxy(i, -1);
        printf("%c",220);
    }
    for(i = 25; i > -1; i--){		//right vertical
        gotoxy(85, i);
        printf("%c",219);
    }

    for(i = 25; i > -1; i--){		//left vertical
        gotoxy(0,i);
        printf("%c",219);
    }

    
    for(i = 1; i < 85; i++){		//bottom horizontal
        gotoxy(i,25);
        printf("%c",220);
    }
}

bool isoperator(char equation)
{
	if((equation == '-') || (equation == '+') || (equation == '/') || (equation == '*') || (equation == '^'))
	{
		return true;
	} else
	{
		return false;
	}
}

bool isparen(char equation)
{
	if((equation == '(') || (equation == ')'))
	{
		return true;
	} else
	{
		return false;
	}
}

int precedence(char oper)
{
	if(oper == '+' || oper == '-')
	{
		return 1;
	} else if(oper == '*' || oper == '/')
	{
		return 2;
	} else if(oper == '^')
	{
		return 3;
	}
}
char pop()
{
	char item ;
	if(top <0)
	{
		printf("stack under flow: invalid infix expression");
		getchar();
		exit(1);
	}
	else
	{
		item = stack[top];
		top = top-1;
		return(item);
	}
}
void clearChoice()
{
	for(i = 12; i <= 17; i++)
	{
		gotoxy(i, 11);
		printf(" ");
	}
	for(i = 1; i <= 84; i++)
	{
		for(j = 13; j <= 18; j++)
		{
			gotoxy(i,j);
			printf(" ");
		}
	}
}
void clearEquation()
{
	for(i = 24; i <= 82; i++)
	{
		gotoxy(i, 6);
		printf(" ");
	}
	for(i = 1; i <= 84; i++)
	{
		for(j = 8; j <= 18; j++)
		{
			gotoxy(i,j);
			printf(" ");
		}
	}
}
void push(char item)
{
	if(top >= SIZE-1)
	{
		printf("\nStack Overflow.");
	}
	else
	{
		top = top+1;
		stack[top] = item;
	}
}

void toPostfix(char equation[], char output[])
{ 
	int i = 0, j = 0;
	char item, checker;

	push('(');
	strcat(equation,")");        
	item = equation[i];       
	
	while(item != '\0')      
	{
		if(item == '(')
		{
			push(item);
		}
		else if(isdigit(item) || isalpha(item))
		{
			output[j] = item;              
			j++;
		}
		else if(isoperator(item))       
		{
			checker = pop();
			while(isoperator(checker) && precedence(checker) >= precedence(item))
			{
				output[j] = checker;                  
				j++;
				checker = pop();                     
			}
			push(checker);

			push(item); 
		}
		else if(item == ')')        
		{
			checker = pop();                  
			while(checker != '(')               
			{
				output[j] = checker;
				j++;
				checker = pop();
			}
		}
		else
		{
			printf("\nInvalid infix Expression.\n"); 
			getchar();
			exit(1);
		}
		i++;


		item = equation[i]; 
	} 
	if(top > 0)
	{
		printf("\nInvalid infix Expression.\n");   
		getchar();
		exit(1);
	}

	output[j] = '\0';
}

void SetColor(int ForgC)
{
     WORD wColor;
     HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
     CONSOLE_SCREEN_BUFFER_INFO csbi;

     if(GetConsoleScreenBufferInfo(hStdOut, &csbi))
     {
          wColor = (csbi.wAttributes & 0xF0) + (ForgC & 0x0F);
          SetConsoleTextAttribute(hStdOut, wColor);
     }
     return;
}
void loadBar()
{
	gotoxy(35, 10); printf("Loading");
	gotoxy(23, 12);
	sleep(1);
	int r,q;
	for(r=1; r<=11; r++)
	{
		for(q =0; q<=2; q++)
		{
			printf("%c",219);
			usleep(100000);
		}
	}
	sleep(2);
	system("cls");
}

int main()
{
	system("COLOR F0");
	loadBar();
	drawRectangle();
	char equation[50], output[50], again[5], tempChoice[10];
	int length, len, choice, parenCounter = 0;
	bool error = false, repeat, restart, hasAnError;
	gotoxy(31,1); printf(" Midterm Project ");
  	gotoxy(23,2); printf(" Created by: Patrick Jan A. Forcadela ");
  	gotoxy(34,3); printf(" BS CoE 2-1 ");
  	do
  	{
  		restart = false;
	  	do
	  	{
	  		error = false, parenCounter = 0;
	  		restart = false;
	  		clearEquation();
	  		for(i = 23; i <= 83; i++)
			{
			   	gotoxy(i, 7);
			   	printf("%c", 223);
			   	gotoxy(i, 5);
			   	printf("%c", 220);
			}
			gotoxy(23, 6);
			printf("%c", 219);
			gotoxy(83, 6);
			printf("%c", 219);
			gotoxy(3, 6); printf("Enter your equation:");
			gotoxy(25,6); scanf("%[^\n]%*c", &equation);
			length = strlen(equation);
			if(isoperator(equation[0]) || equation[0] == ')' || isoperator(equation[length - 1]) || length == 1)
			{
				error = true;
			}
			for(i = 0; i < length; i++)
			{
				if(!isalpha(equation[i]) && !isdigit(equation[i]) && !isparen(equation[i]) && !isoperator(equation[i]))
				{
					error = true;
				}
				if(isalpha(equation[i]) && isalpha(equation[i+1]) || (isoperator(equation[i]) && isoperator(equation[i+1])) || (isdigit(equation[i]) && isdigit(equation[i+1])))
				{
					error = true;
				}
				if(equation[i] == ')' && (isalpha(equation[i+1]) || isdigit(equation[i+1])))
				{
					error = true;
				}
				if(equation[i] == '(')
				{
					parenCounter++;
				}
				if(equation[i] == ')')
				{
					parenCounter--;
				}
			}
			if(!error && parenCounter == 0)
			{
				do
				{
					hasAnError = false;
					repeat = false;	
					clearChoice();
					gotoxy(3, 8); printf("1. Display the prefix of this equation");
					gotoxy(3, 9); printf("2. Display the postfix of this equation");
					gotoxy(3, 11); printf("Choice:");
					gotoxy(11, 11); printf("%c", 219);
					gotoxy(17, 11);	printf("%c", 219);
					for(i = 11; i <= 17; i++)
					{
						gotoxy(i, 10); printf("%c", 220);
						gotoxy(i, 12); printf("%c", 223);
					}
					gotoxy(14, 11); scanf("%[^\n]%*c", &tempChoice);
					len = strlen(tempChoice);
					for(i = 0; i <= len; i++)
					{
						if(isalpha(tempChoice[i]) || ispunct(tempChoice[i]) || isspace(tempChoice[i]))
						{
							repeat = true;
						}
					}
					choice = atoi(tempChoice);
					if(repeat == false && choice < 3)
					{
						switch(choice)
						{
							case 1:
								strrev(equation);
								for(int i = 0; i < length; i++)
								{
									if(equation[i] == '(')
									{
										equation[i] = ')';
									} else if(equation[i] == ')')
									{
										equation[i] = '(';
									}
								}
								toPostfix(equation, output);
								strrev(output);
								gotoxy(3, 13); printf("Prefix expression: %s", output);
								repeat = false;
					 			break;
							case 2:
								toPostfix(equation, output);
								gotoxy(3, 13); printf("Postfix expression: %s", output);
								repeat = false;	
								break;
						}
					} else
					{
						gotoxy(3, 13); printf("Error!");
						SetColor(28);
						gotoxy(11, 11); printf("%c", 219);
						gotoxy(17, 11);	printf("%c", 219);
						for(int i = 11; i <= 17; i++)
						{
							gotoxy(i, 10); printf("%c", 220);
							gotoxy(i, 12); printf("%c", 223);
						}
						SetColor(0);
						gotoxy(3, 15); printf("Do you want to try again?");
						scanf("%s", &again);
						if((again[0] == 'Y' || again[0] == 'y') || (again[1] == 'E' || again[1] == 'e') || (again[2] == 'S' || again[2] == 's'))
						{
							fflush(stdin);
							repeat = true;
						} else
						{
							return 0;
						}
					}
				} while(repeat);
				restart = false;
			} else
			{
				gotoxy(3, 8); printf("Error!");
				SetColor(28);
				for(i = 23; i <= 83; i++)
			    {
			    	gotoxy(i, 7);
			    	printf("%c", 223);
			    	gotoxy(i, 5);
			    	printf("%c", 220);
				}
				gotoxy(23, 6);
				printf("%c", 219);
				gotoxy(83, 6);
				printf("%c", 219);
				SetColor(0);
				gotoxy(3, 10); printf("Do you want to try again? (Yes or no): ");
				scanf("%s", &again);
				if((again[0] == 'Y' || again[0] == 'y') || (again[1] == 'E' || again[1] == 'e') || (again[2] == 'S' || again[2] == 's'))
				{
					fflush(stdin);
					restart = true;
				} else
				{
					return 0;
				}
			}
		} while(restart);
		gotoxy(3, 17); printf("Do you want to try again? (Yes or no):");
		scanf("%s", &again);
		if((again[0] == 'Y' || again[0] == 'y') || (again[1] == 'E' || again[1] == 'e') || (again[2] == 'S' || again[2] == 's'))
		{
			fflush(stdin);
			restart = true;
		} else
		{
			return 0;
		}
	} while(restart);
	return 0;
	
}
